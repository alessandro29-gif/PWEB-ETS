(function () {
var s = LR.sesi();
if (!s || s.peran !== "admin") {
window.location.replace("login.html?peran=admin&pesan=wajib");
return;
}
document.getElementById("isi-halaman").style.display = "block";

var badan = document.getElementById("badan-tabel");
var kosong = document.getElementById("info-kosong");
var bungkus = document.getElementById("bungkus-tabel");
var jumlah = document.getElementById("jumlah-hasil");
var cari = document.getElementById("cari");
var saring = document.getElementById("saring");
var formEdit = document.getElementById("form-edit");
var idEdit = null;
var idHapus = null;

LR.pasangForm(formEdit);

function cocok(m, kata, jenis) {
if (jenis && m.jenis !== jenis) return false;
if (!kata) return true;
return m.nama.toLowerCase().indexOf(kata) !== -1 || m.nomor.toLowerCase().indexOf(kata) !== -1;
}

function gambar() {
var kata = cari.value.trim().toLowerCase();
var semua = LR.semuaAnggota();
var hasil = semua.filter(function (m) { return cocok(m, kata, saring.value); });
hasil.sort(function (a, b) { return a.nama.localeCompare(b.nama, "id"); });

var h = "";
hasil.forEach(function (m, i) {
var j = LR.JENIS[m.jenis] || { label: m.jenis, nomor: "No." };
var unit = m.jenis === "mahasiswa" ? LR.esc(m.prodi) + '<span class="kecil">' + LR.esc(m.fakultas) + "</span>" : "-";
h += "<tr>" +
"<td>" + (i + 1) + "</td>" +
'<td><span class="nama">' + LR.esc(m.nama) + '</span><span class="kecil">' + LR.esc(m.email) + "</span></td>" +
'<td><span class="lencana lencana-' + LR.esc(m.jenis) + '">' + j.label + "</span></td>" +
"<td>" + LR.esc(m.nomor) + '<span class="kecil">' + j.nomor + "</span></td>" +
"<td>" + unit + "</td>" +
"<td>" + LR.esc(m.telepon) + "</td>" +
'<td class="aksi-baris">' +
'<button type="button" class="tombol-kecil" data-aksi="detail" data-id="' + LR.esc(m.id) + '" aria-label="Detail ' + LR.esc(m.nama) + '">Detail</button>' +
'<button type="button" class="tombol-kecil" data-aksi="edit" data-id="' + LR.esc(m.id) + '" aria-label="Edit ' + LR.esc(m.nama) + '">Edit</button>' +
'<button type="button" class="tombol-kecil hapus" data-aksi="hapus" data-id="' + LR.esc(m.id) + '" aria-label="Hapus ' + LR.esc(m.nama) + '">Hapus</button>' +
"</td></tr>";
});
badan.innerHTML = h;
bungkus.style.display = hasil.length ? "block" : "none";
kosong.style.display = hasil.length ? "none" : "block";
if (!semua.length) {
kosong.querySelector("p").innerHTML = 'Belum ada anggota. Data akan muncul setelah calon anggota mengisi <a href="pendaftaran.html">formulir pendaftaran</a>.';
} else {
kosong.querySelector("p").textContent = "Tidak ada anggota yang cocok dengan pencarian. Coba nama atau nomor induk lain.";
}
jumlah.textContent = "Menampilkan " + hasil.length + " dari " + semua.length + " anggota";
}

function cariAnggota(id) {
return LR.semuaAnggota().filter(function (m) { return m.id === id; })[0];
}

function bukaDetail(m) {
var j = LR.JENIS[m.jenis];
var h = "<dt>Nama</dt><dd>" + LR.esc(m.nama) + "</dd>" +
"<dt>Jenis Keanggotaan</dt><dd>" + j.label + "</dd>" +
"<dt>" + j.nomor + "</dt><dd>" + LR.esc(m.nomor) + "</dd>";
if (m.jenis === "mahasiswa") {
h += "<dt>Fakultas</dt><dd>" + LR.esc(m.fakultas) + "</dd><dt>Departemen</dt><dd>" + LR.esc(m.departemen) + "</dd><dt>Program Studi</dt><dd>" + LR.esc(m.prodi) + "</dd>";
}
h += "<dt>Alamat</dt><dd>" + LR.esc(m.alamat) + "</dd><dt>Telepon</dt><dd>" + LR.esc(m.telepon) + "</dd><dt>Email</dt><dd>" + LR.esc(m.email) + "</dd>" +
"<dt>Terdaftar</dt><dd>" + LR.tanggalIndo(m.tanggal) + "</dd>";
document.getElementById("detail-isi").innerHTML = h;
$("#modal-detail").modal("show");
}

badan.addEventListener("click", function (e) {
var t = e.target;
var aksi = t.getAttribute("data-aksi");
if (!aksi) return;
var m = cariAnggota(t.getAttribute("data-id"));
if (!m) { LR.toast("Data anggota tidak ditemukan.", "galat"); gambar(); return; }
if (aksi === "detail") bukaDetail(m);
if (aksi === "edit") {
idEdit = m.id;
LR.isiForm(formEdit, m);
$("#modal-edit").modal("show");
}
if (aksi === "hapus") {
idHapus = m.id;
document.getElementById("hapus-nama").textContent = m.nama;
$("#modal-hapus").modal("show");
}
});

formEdit.addEventListener("submit", function (e) {
e.preventDefault();
var err = LR.validasi(formEdit, idEdit);
if (!LR.tampilkanError(formEdit, err)) {
LR.toast("Perubahan belum bisa disimpan. Periksa kolom yang ditandai.", "galat");
return;
}
if (LR.perbaruiAnggota(idEdit, LR.dataBersih(formEdit))) {
$("#modal-edit").modal("hide");
gambar();
LR.toast("Data anggota berhasil diperbarui.");
} else {
LR.toast("Data gagal diperbarui.", "galat");
}
});
document.getElementById("simpan-edit").addEventListener("click", function () {
formEdit.dispatchEvent(new Event("submit", { cancelable: true }));
});

document.getElementById("konfirmasi-hapus").addEventListener("click", function () {
if (LR.hapusAnggota(idHapus)) {
$("#modal-hapus").modal("hide");
gambar();
LR.toast("Anggota berhasil dihapus.");
} else {
LR.toast("Data gagal dihapus.", "galat");
}
});

cari.addEventListener("input", gambar);
saring.addEventListener("change", gambar);
gambar();
})();
