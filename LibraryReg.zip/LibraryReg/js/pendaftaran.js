(function () {
var form = document.getElementById("form-daftar");
var panelForm = document.getElementById("panel-form");
var panelSukses = document.getElementById("panel-sukses");
var ringkasan = document.getElementById("ringkasan");
var tombolLagi = document.getElementById("daftar-lagi");

LR.pasangForm(form);

var s = LR.sesi();
if (s && s.peran === "anggota" && s.nama) {
form.elements["nama"].value = s.nama;
}

form.addEventListener("submit", function (e) {
e.preventDefault();
var err = LR.validasi(form, null);
if (!LR.tampilkanError(form, err)) {
LR.toast("Formulir belum lengkap. Periksa kolom yang ditandai.", "galat");
return;
}
var data = LR.dataBersih(form);
if (!LR.tambahAnggota(data)) {
LR.toast("Data gagal disimpan. Penyimpanan browser mungkin penuh atau dinonaktifkan.", "galat");
return;
}
var j = LR.JENIS[data.jenis];
var h = "<dt>Nama</dt><dd>" + LR.esc(data.nama) + "</dd>" +
"<dt>Jenis Keanggotaan</dt><dd>" + j.label + "</dd>" +
"<dt>" + j.nomor + "</dt><dd>" + LR.esc(data.nomor) + "</dd>";
if (data.jenis === "mahasiswa") h += "<dt>Program Studi</dt><dd>" + LR.esc(data.prodi) + ", " + LR.esc(data.fakultas) + "</dd>";
h += "<dt>Telepon</dt><dd>" + LR.esc(data.telepon) + "</dd><dt>Email</dt><dd>" + LR.esc(data.email) + "</dd>";
ringkasan.innerHTML = h;
panelForm.style.display = "none";
panelSukses.style.display = "block";
panelSukses.querySelector("h2").focus();
window.scrollTo(0, 0);
LR.toast("Pendaftaran berhasil disimpan.");
});

tombolLagi.addEventListener("click", function () {
form.reset();
LR.pasangForm(form);
panelSukses.style.display = "none";
panelForm.style.display = "block";
form.elements["jenis"][0].focus();
});
})();
