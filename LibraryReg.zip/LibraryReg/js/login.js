(function () {
var param = new URLSearchParams(window.location.search);
var peran = param.get("peran") === "admin" ? "admin" : "anggota";
var tab = document.querySelectorAll(".pilihan-jenis input[name='peran']");
var formAnggota = document.getElementById("form-anggota");
var formAdmin = document.getElementById("form-admin");
var info = document.getElementById("info-login");

function tampil(p) {
peran = p;
for (var i = 0; i < tab.length; i++) tab[i].checked = tab[i].value === p;
formAnggota.style.display = p === "anggota" ? "block" : "none";
formAdmin.style.display = p === "admin" ? "block" : "none";
}
tampil(peran);

if (param.get("pesan") === "wajib") {
info.textContent = "Halaman Kelola Data hanya untuk administrator. Masuk sebagai Administrator untuk melanjutkan.";
info.className = "kotak-info galat";
info.style.display = "block";
}
for (var i = 0; i < tab.length; i++) {
tab[i].addEventListener("change", function (e) { tampil(e.target.value); });
}

function galat(id, pesan) {
var el = document.getElementById(id);
el.textContent = pesan;
el.parentNode.classList.toggle("has-error", !!pesan);
}

formAnggota.addEventListener("submit", function (e) {
e.preventDefault();
var nama = formAnggota.elements["nama"].value.trim();
if (nama.length < 3) {
galat("err-login-nama", "Nama minimal 3 karakter.");
formAnggota.elements["nama"].focus();
return;
}
galat("err-login-nama", "");
LR.masuk("anggota", nama);
window.location.href = "pendaftaran.html";
});

formAdmin.addEventListener("submit", function (e) {
e.preventDefault();
var u = formAdmin.elements["username"].value.trim();
var p = formAdmin.elements["password"].value;
if (!u) { galat("err-login-user", "Username wajib diisi."); formAdmin.elements["username"].focus(); return; }
galat("err-login-user", "");
if (!p) { galat("err-login-pass", "Password wajib diisi."); formAdmin.elements["password"].focus(); return; }
if (!LR.cekAdmin(u, p)) {
galat("err-login-pass", "Username atau password salah.");
LR.toast("Login gagal. Periksa username dan password.", "galat");
return;
}
galat("err-login-pass", "");
LR.masuk("admin", "Administrator");
window.location.href = "kelola.html";
});
})();
