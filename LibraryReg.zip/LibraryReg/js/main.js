var LR = (function () {
var KUNCI_DATA = "libraryreg_anggota";
var KUNCI_SESI = "libraryreg_sesi";
var KUNCI_AWAL = "libraryreg_data_awal";
var AKUN_ADMIN = { username: "admin", password: "admin123" };

var JENIS = {
mahasiswa: { label: "Mahasiswa", nomor: "NRP" },
dosen: { label: "Dosen", nomor: "NIDN" },
tendik: { label: "Tenaga Kependidikan", nomor: "NITK" }
};

var AKADEMIK = {
"Fakultas Sains dan Analitika Data": {
"Departemen Matematika": ["S1 Matematika", "S2 Matematika"],
"Departemen Fisika": ["S1 Fisika", "S1 Teknik Fisika"],
"Departemen Statistika": ["S1 Statistika", "S1 Sains Aktuaria"]
},
"Fakultas Teknologi Elektro dan Informatika Cerdas": {
"Departemen Teknik Elektro": ["S1 Teknik Elektro"],
"Departemen Teknik Informatika": ["S1 Teknik Informatika", "S2 Teknik Informatika"],
"Departemen Sistem Informasi": ["S1 Sistem Informasi", "S1 Teknologi Informasi"]
},
"Fakultas Teknologi Industri dan Rekayasa Sistem": {
"Departemen Teknik Mesin": ["S1 Teknik Mesin"],
"Departemen Teknik Kimia": ["S1 Teknik Kimia"],
"Departemen Teknik Industri": ["S1 Teknik Industri", "S1 Teknik Logistik"]
},
"Fakultas Teknik Sipil, Perencanaan, dan Kebumian": {
"Departemen Teknik Sipil": ["S1 Teknik Sipil"],
"Departemen Arsitektur": ["S1 Arsitektur"],
"Departemen Teknik Lingkungan": ["S1 Teknik Lingkungan"]
},
"Fakultas Desain Kreatif dan Bisnis Digital": {
"Departemen Desain Produk": ["S1 Desain Produk Industri"],
"Departemen Manajemen Bisnis": ["S1 Manajemen Bisnis"]
}
};

var DATA_AWAL = [
{ jenis: "mahasiswa", nama: "Nadia Putri Rahma", nomor: "5025251001", fakultas: "Fakultas Teknologi Elektro dan Informatika Cerdas", departemen: "Departemen Teknik Informatika", prodi: "S1 Teknik Informatika", alamat: "Jl. Keputih Tegal No. 12, Sukolilo, Surabaya", telepon: "081234567801", email: "nadia.putri@mail.example" },
{ jenis: "mahasiswa", nama: "Rizky Aditya Pratama", nomor: "5025251002", fakultas: "Fakultas Teknologi Industri dan Rekayasa Sistem", departemen: "Departemen Teknik Mesin", prodi: "S1 Teknik Mesin", alamat: "Jl. Gebang Lor No. 7, Surabaya", telepon: "081234567802", email: "rizky.aditya@mail.example" },
{ jenis: "mahasiswa", nama: "Salsabila Anindya", nomor: "5025251003", fakultas: "Fakultas Sains dan Analitika Data", departemen: "Departemen Statistika", prodi: "S1 Statistika", alamat: "Perumahan ITS Blok U No. 4, Surabaya", telepon: "081234567803", email: "salsabila.a@mail.example" },
{ jenis: "dosen", nama: "Dr. Bambang Hermawan, M.T.", nomor: "0012058801", fakultas: "", departemen: "", prodi: "", alamat: "Jl. Raya Kertajaya Indah No. 21, Surabaya", telepon: "081234567804", email: "bambang.h@univ.example" },
{ jenis: "dosen", nama: "Prof. Siti Marlina, Ph.D.", nomor: "0023067502", fakultas: "", departemen: "", prodi: "", alamat: "Jl. Manyar Kertoarjo No. 9, Surabaya", telepon: "081234567805", email: "siti.marlina@univ.example" },
{ jenis: "tendik", nama: "Agus Santoso, S.Kom.", nomor: "198507122010", fakultas: "", departemen: "", prodi: "", alamat: "Jl. Mulyorejo Utara No. 33, Surabaya", telepon: "081234567806", email: "agus.santoso@univ.example" }
];

function bacaJSON(kunci, awal) {
try {
var mentah = localStorage.getItem(kunci);
return mentah ? JSON.parse(mentah) : awal;
} catch (e) { return awal; }
}
function tulisJSON(kunci, nilai) {
try { localStorage.setItem(kunci, JSON.stringify(nilai)); return true; } catch (e) { return false; }
}
function buatId() {
return "m" + Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
}
function siapkanDataAwal() {
try {
if (localStorage.getItem(KUNCI_AWAL)) return;
if (!localStorage.getItem(KUNCI_DATA)) {
var awal = DATA_AWAL.map(function (m, i) {
var salin = {};
for (var k in m) salin[k] = m[k];
salin.id = buatId() + i;
salin.tanggal = new Date(Date.now() - (6 - i) * 86400000).toISOString();
return salin;
});
tulisJSON(KUNCI_DATA, awal);
}
localStorage.setItem(KUNCI_AWAL, "1");
} catch (e) {}
}
function semuaAnggota() { return bacaJSON(KUNCI_DATA, []); }
function simpanSemua(daftar) { return tulisJSON(KUNCI_DATA, daftar); }
function tambahAnggota(data) {
var daftar = semuaAnggota();
data.id = buatId();
data.tanggal = new Date().toISOString();
daftar.push(data);
return simpanSemua(daftar);
}
function perbaruiAnggota(id, data) {
var daftar = semuaAnggota();
for (var i = 0; i < daftar.length; i++) {
if (daftar[i].id === id) {
data.id = id;
data.tanggal = daftar[i].tanggal;
daftar[i] = data;
return simpanSemua(daftar);
}
}
return false;
}
function hapusAnggota(id) {
var daftar = semuaAnggota().filter(function (m) { return m.id !== id; });
return simpanSemua(daftar);
}

function sesi() { return bacaJSON(KUNCI_SESI, null); }
function masuk(peran, nama) { return tulisJSON(KUNCI_SESI, { peran: peran, nama: nama }); }
function keluar() { try { localStorage.removeItem(KUNCI_SESI); } catch (e) {} }
function cekAdmin(username, password) {
return username === AKUN_ADMIN.username && password === AKUN_ADMIN.password;
}

function esc(teks) {
return String(teks == null ? "" : teks).replace(/[&<>"']/g, function (c) {
return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c];
});
}
function tanggalIndo(iso) {
var d = new Date(iso);
if (isNaN(d.getTime())) return "-";
return d.toLocaleDateString("id-ID", { day: "numeric", month: "long", year: "numeric" });
}
function toast(pesan, tipe) {
var area = document.getElementById("toast-area");
if (!area) {
area = document.createElement("div");
area.id = "toast-area";
area.setAttribute("role", "status");
area.setAttribute("aria-live", "polite");
document.body.appendChild(area);
}
var el = document.createElement("div");
el.className = "toast-item" + (tipe === "galat" ? " galat" : "");
el.textContent = pesan;
area.appendChild(el);
setTimeout(function () { if (el.parentNode) el.parentNode.removeChild(el); }, 4200);
}

function opsi(daftar, terpilih, placeholder) {
var h = '<option value="">' + placeholder + "</option>";
daftar.forEach(function (x) {
h += '<option value="' + esc(x) + '"' + (x === terpilih ? " selected" : "") + ">" + esc(x) + "</option>";
});
return h;
}
function grup(nama, label, kontrol, petunjuk) {
return '<div class="form-group" data-grup="' + nama + '">' +
'<label for="f-' + nama + '" id="lbl-' + nama + '">' + label + "</label>" + kontrol +
(petunjuk ? '<p class="petunjuk" id="pt-' + nama + '">' + petunjuk + "</p>" : "") +
'<p class="pesan-error" id="err-' + nama + '" role="alert"></p></div>';
}
function htmlForm() {
var radios = "";
Object.keys(JENIS).forEach(function (k) {
radios += '<label><input type="radio" name="jenis" value="' + k + '"><span>' + JENIS[k].label + "</span></label>";
});
return '<div class="form-group" data-grup="jenis">' +
'<span class="judul-isian" id="lbl-jenis">Jenis Keanggotaan</span>' +
'<div class="pilihan-jenis" role="radiogroup" aria-labelledby="lbl-jenis">' + radios + "</div>" +
'<p class="pesan-error" id="err-jenis" role="alert"></p></div>' +
grup("nama", "Nama Lengkap", '<input type="text" class="form-control" id="f-nama" name="nama" autocomplete="name" maxlength="80">') +
grup("nomor", '<span id="lbl-nomor-teks">NRP / NIDN / NITK</span>', '<input type="text" class="form-control" id="f-nomor" name="nomor" inputmode="numeric" autocomplete="off" maxlength="20">', "Pilih jenis keanggotaan dahulu. Nomor induk harus unik.") +
grup("fakultas", "Fakultas", '<select class="form-control" id="f-fakultas" name="fakultas"></select>') +
grup("departemen", "Departemen", '<select class="form-control" id="f-departemen" name="departemen"></select>') +
grup("prodi", "Program Studi", '<select class="form-control" id="f-prodi" name="prodi"></select>') +
'<p class="petunjuk" id="info-akademik" style="display:none;margin:-8px 0 20px">Dosen dan tenaga kependidikan tidak perlu mengisi fakultas, departemen, dan program studi.</p>' +
grup("alamat", "Alamat Tinggal", '<textarea class="form-control" id="f-alamat" name="alamat" rows="3" maxlength="200" autocomplete="street-address"></textarea>') +
grup("telepon", "Nomor Telepon", '<input type="tel" class="form-control" id="f-telepon" name="telepon" inputmode="tel" autocomplete="tel" maxlength="18" placeholder="Contoh: 081234567890">') +
grup("email", "Email", '<input type="email" class="form-control" id="f-email" name="email" autocomplete="email" maxlength="80" placeholder="nama@email.com">');
}
function ambilNilai(form) {
var v = {};
["jenis", "nama", "nomor", "fakultas", "departemen", "prodi", "alamat", "telepon", "email"].forEach(function (n) {
var el = form.elements[n];
v[n] = el && el.value ? String(el.value).trim() : "";
});
return v;
}
function aturAkademik(form) {
var jenis = form.elements["jenis"].value;
var mhs = jenis === "mahasiswa";
["fakultas", "departemen", "prodi"].forEach(function (n) {
var el = form.elements[n];
el.disabled = !mhs;
if (!mhs) el.value = "";
});
var info = form.querySelector("#info-akademik");
if (info) info.style.display = (jenis === "dosen" || jenis === "tendik") ? "block" : "none";
var label = form.querySelector("#lbl-nomor-teks");
if (label) label.textContent = jenis ? JENIS[jenis].nomor : "NRP / NIDN / NITK";
var pt = form.querySelector("#pt-nomor");
if (pt) {
pt.textContent = jenis === "mahasiswa" ? "NRP terdiri dari 10 angka dan harus unik."
: jenis === "dosen" ? "NIDN terdiri dari 10 angka dan harus unik."
: jenis === "tendik" ? "NITK terdiri dari 8 sampai 20 angka dan harus unik."
: "Pilih jenis keanggotaan dahulu. Nomor induk harus unik.";
}
}
function isiDepartemen(form, fakultas, terpilih) {
var d = fakultas && AKADEMIK[fakultas] ? Object.keys(AKADEMIK[fakultas]) : [];
form.elements["departemen"].innerHTML = opsi(d, terpilih, "Pilih Departemen");
}
function isiProdi(form, fakultas, departemen, terpilih) {
var p = fakultas && departemen && AKADEMIK[fakultas] && AKADEMIK[fakultas][departemen] ? AKADEMIK[fakultas][departemen] : [];
form.elements["prodi"].innerHTML = opsi(p, terpilih, "Pilih Program Studi");
}
function pasangForm(form) {
form.setAttribute("novalidate", "novalidate");
form.innerHTML = htmlForm();
form.elements["fakultas"].innerHTML = opsi(Object.keys(AKADEMIK), "", "Pilih Fakultas");
isiDepartemen(form, "", "");
isiProdi(form, "", "", "");
aturAkademik(form);
form.addEventListener("change", function (e) {
var n = e.target.name;
if (n === "jenis") aturAkademik(form);
if (n === "fakultas") { isiDepartemen(form, e.target.value, ""); isiProdi(form, "", "", ""); }
if (n === "departemen") isiProdi(form, form.elements["fakultas"].value, e.target.value, "");
});
form.addEventListener("input", function (e) {
bersihkanError(form, e.target.name);
});
}
function isiForm(form, m) {
var r = form.querySelectorAll('input[name="jenis"]');
for (var i = 0; i < r.length; i++) r[i].checked = r[i].value === m.jenis;
aturAkademik(form);
form.elements["nama"].value = m.nama || "";
form.elements["nomor"].value = m.nomor || "";
form.elements["fakultas"].value = m.fakultas || "";
isiDepartemen(form, m.fakultas, m.departemen);
isiProdi(form, m.fakultas, m.departemen, m.prodi);
form.elements["alamat"].value = m.alamat || "";
form.elements["telepon"].value = m.telepon || "";
form.elements["email"].value = m.email || "";
bersihkanError(form);
}
function bersihkanError(form, nama) {
var grupEl = form.querySelectorAll("[data-grup]");
for (var i = 0; i < grupEl.length; i++) {
var n = grupEl[i].getAttribute("data-grup");
if (nama && n !== nama) continue;
grupEl[i].classList.remove("has-error");
var p = grupEl[i].querySelector(".pesan-error");
if (p) p.textContent = "";
var k = form.elements[n];
if (k && k.setAttribute && n !== "jenis") k.removeAttribute("aria-invalid");
}
}
var POLA_NAMA = /^[A-Za-z\u00C0-\u024F .,'\-]{3,80}$/;
var POLA_EMAIL = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;
var POLA_TELEPON = /^(\+62|62|0)[0-9]{8,13}$/;
function validasi(form, idAbaikan) {
var v = ambilNilai(form);
var err = {};
if (!v.jenis) err.jenis = "Pilih salah satu jenis keanggotaan.";
if (!v.nama) err.nama = "Nama lengkap wajib diisi.";
else if (!POLA_NAMA.test(v.nama)) err.nama = "Nama minimal 3 karakter dan hanya berisi huruf, spasi, titik, koma, atau tanda hubung.";
if (!v.nomor) {
err.nomor = (v.jenis ? JENIS[v.jenis].nomor : "Nomor induk") + " wajib diisi.";
} else if (v.jenis === "mahasiswa" && !/^\d{10}$/.test(v.nomor)) {
err.nomor = "NRP harus terdiri dari tepat 10 angka.";
} else if (v.jenis === "dosen" && !/^\d{10}$/.test(v.nomor)) {
err.nomor = "NIDN harus terdiri dari tepat 10 angka.";
} else if (v.jenis === "tendik" && !/^\d{8,20}$/.test(v.nomor)) {
err.nomor = "NITK harus terdiri dari 8 sampai 20 angka.";
} else if (!v.jenis && !/^\d{8,20}$/.test(v.nomor)) {
err.nomor = "Nomor induk hanya boleh berisi angka (8 sampai 20 digit).";
} else {
var kembar = semuaAnggota().some(function (m) { return m.nomor === v.nomor && m.id !== idAbaikan; });
if (kembar) err.nomor = "Nomor induk ini sudah terdaftar. Gunakan nomor lain atau hubungi petugas.";
}
if (v.jenis === "mahasiswa") {
if (!v.fakultas) err.fakultas = "Fakultas wajib dipilih.";
if (!v.departemen) err.departemen = "Departemen wajib dipilih.";
if (!v.prodi) err.prodi = "Program studi wajib dipilih.";
}
if (!v.alamat) err.alamat = "Alamat tinggal wajib diisi.";
else if (v.alamat.length < 10) err.alamat = "Alamat terlalu singkat. Tulis jalan, nomor, dan kota.";
var telp = v.telepon.replace(/[\s\-]/g, "");
if (!v.telepon) err.telepon = "Nomor telepon wajib diisi.";
else if (!POLA_TELEPON.test(telp)) err.telepon = "Format telepon tidak valid. Contoh: 081234567890 atau +6281234567890.";
if (!v.email) err.email = "Email wajib diisi.";
else if (!POLA_EMAIL.test(v.email)) err.email = "Format email tidak valid. Contoh: nama@email.com.";
return err;
}
function tampilkanError(form, err) {
bersihkanError(form);
var pertama = null;
["jenis", "nama", "nomor", "fakultas", "departemen", "prodi", "alamat", "telepon", "email"].forEach(function (n) {
if (!err[n]) return;
var g = form.querySelector('[data-grup="' + n + '"]');
g.classList.add("has-error");
form.querySelector("#err-" + n).textContent = err[n];
var k = form.elements[n];
if (n !== "jenis" && k) {
k.setAttribute("aria-invalid", "true");
k.setAttribute("aria-describedby", "err-" + n);
}
if (!pertama) pertama = n === "jenis" ? form.querySelector('input[name="jenis"]') : k;
});
if (pertama) pertama.focus();
return !pertama;
}
function dataBersih(form) {
var v = ambilNilai(form);
v.telepon = v.telepon.replace(/[\s\-]/g, "");
v.email = v.email.toLowerCase();
if (v.jenis !== "mahasiswa") { v.fakultas = ""; v.departemen = ""; v.prodi = ""; }
return v;
}

function mulaiNavigasi() {
var tombol = document.getElementById("nav-toggle");
var menu = document.getElementById("menu-utama");
if (tombol && menu) {
tombol.addEventListener("click", function () {
var buka = menu.classList.toggle("terbuka");
tombol.setAttribute("aria-expanded", buka ? "true" : "false");
});
}
var s = sesi();
var item = document.getElementById("nav-masuk");
if (item && s) {
var a = item.querySelector("a");
a.textContent = "Keluar";
a.setAttribute("href", "#");
a.setAttribute("title", "Masuk sebagai " + s.nama);
a.addEventListener("click", function (e) {
e.preventDefault();
keluar();
window.location.href = "index.html";
});
}
}

siapkanDataAwal();
document.addEventListener("DOMContentLoaded", function () {
mulaiNavigasi();
if (window.jQuery && window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches) {
jQuery("#slider-hero").carousel("pause");
}
});

return {
JENIS: JENIS, AKADEMIK: AKADEMIK,
semuaAnggota: semuaAnggota, tambahAnggota: tambahAnggota, perbaruiAnggota: perbaruiAnggota, hapusAnggota: hapusAnggota,
sesi: sesi, masuk: masuk, keluar: keluar, cekAdmin: cekAdmin,
esc: esc, tanggalIndo: tanggalIndo, toast: toast,
pasangForm: pasangForm, isiForm: isiForm, validasi: validasi, tampilkanError: tampilkanError, dataBersih: dataBersih, bersihkanError: bersihkanError
};
})();
